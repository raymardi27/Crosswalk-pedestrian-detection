#include "utilities.h"


void detectFaces(cv::Mat &blob, std::vector<cv::Mat> &outs) {
    faceNet.setInput(blob);
    faceNet.forward(outs, faceNet.getUnconnectedOutLayersNames());
}

void configNetwork(cv::dnn:Net &net){

    // Check if OpenCV is built with CUDA support and set CUDA as preferable backend and target
    if (cuda::getCudaEnabledDeviceCount() > 0) {
        net.setPreferableBackend(DNN_BACKEND_CUDA);
        net.setPreferableTarget(DNN_TARGET_CUDA);
        cout << "Using CUDA for processing\n";
    } else {
        cerr << "CUDA not available on this device; using CPU.\n";
        net.setPreferableBackend(DNN_BACKEND_OPENCV);
        net.setPreferableTarget(DNN_TARGET_CPU);
    }
}

void getBoxes(const std::vector<cv::Mat>&outs, std::vector<cv::Rect> &boxes, std::vector<int> &classIds,std::vector<float> &confidences) {

    for (size_t i = 0; i < outs.size(); ++i) {
        float* data = (float*)outs[i].data;
        for (int j = 0; j < outs[i].rows; ++j, data += outs[i].cols) {
            cv::Mat scores = outs[i].row(j).colRange(5, outs[i].cols);
            cv::Point classIdPoint;
            cv::minMaxLoc(scores, nullptr, &confidence, nullptr, &classIdPoint);
            if (confidence > CONFIDENCE_THRESHOLD && classIdPoint.x < 2){
                int centerX = (int)(data[0] * frame.cols);
                int centerY = (int)(data[1] * frame.rows);
                int width = (int)(data[2] * frame.cols);
                int height = (int)(data[3] * frame.rows);
                int left = centerX - width / 2;
                int top = centerY - height / 2;

                classIds.push_back(classIdPoint.x);
                confidences.push_back((float)confidence);
                boxes.push_back(Rect(left, top, width, height));
            }
        }
    }

}

void postProcess(cv::Mat &frame, const std::vector<cv::Mat> &outs,bool faceProcess = false, bool driverView = false) {

    confidence_threshold = faceProcess? FACE_CONFIDENCE_THRESHOLD : CONFIDENCE_THRESHOLD

    std::vector<int> classIds;
    std::vector<float> confidences;
    std::vector<cv::Rect> boxes;
    std::vector<int> indices;
    cv::Rect box;

    getBoxes(outs, boxes, classIds, confidences);

    cv::NMSBoxes(boxes, confidences, confidence_threshold,NMS_THRESHOLD,indices);

    for(int i : indices){
        box = boxes[idx];
        if(faceProces){
            blurFaces(box, frame);
        }
        else{
            classId = classIds[idx];
            confidence = confidences[idx];
            annotate(classId,confidence, box,frame, driverView);
        }
    } 
}

void blurFaces(cv::Rect &box, cv::Mat& frame){
    int left = box.x, top = box.y, right = box.x + box.width, bottom = box.y + box.height;

    if(left >= 0 && top >= 0 && right <= frame.cols && bottom <= frame.rows) {
        cv::Mat roi = frame(box);
        cv::GaussianBlur(roi, roi, cv::Size(31,31),12.0,12.0);
        roi.copyTo(frame(roi));
    }
}

void annotate(int classId, float confidence,cv::Rect &box, cv::Mat& frame, bool driverView) {
    int left = box.x, top = box.y, right = box.x + box.width, bottom = box.y + box.height;

    cv::rectange(frame, cv::Point(left,top),cv::Point(right,bottom), Scalar(0,255,0),3);
    std::string label = format("%.2f", conf);
    std::string classP = classId? "Cyclist" : "Person";
    label = classP + ": " + label;
    cv::putText(frame, label, Point(left, top - 5), FONT_HERSHEY_SIMPLEX, 0.5, Scalar(0, 255, 0), 2);
    if(driverView) {
        putText(frame, "Slow Down!", Point(frame.cols / 3, 50), FONT_HERSHEY_SIMPLEX, 2, Scalar(0,0,255),4);

    }else{
        std::cout<< "Extend Green Signal Time"<<endl;
    }
    

}